# image_detail.py
import flet as ft
import os
from datetime import datetime

# main.pyと同じWEB_FLAGを使用
# WEB_FLAG = False


class ImageDetailView:
    def __init__(self, page: ft.Page, image_path: str, WEB_FLAG: bool):
        self.page = page
        self.image_path = image_path
        self.WEB_FLAG = WEB_FLAG
        self.controls = []
        self._build()

    def _get_file_info(self):
        if self.WEB_FLAG:
            # Web環境では静的な情報を返す
            filename = os.path.basename(self.image_path)
            return {
                "filename": filename,
                "created": "2024-02-18 12:00:00",  # サンプルの日時
                "modified": "2024-02-18 12:00:00",  # サンプルの日時
                "size": "2.5 MB",  # サンプルのサイズ
            }
        else:
            # ローカル環境での処理（既存のコード）
            file_stat = os.stat(self.image_path)
            filename = os.path.basename(self.image_path)
            created_time = datetime.fromtimestamp(file_stat.st_ctime).strftime("%Y-%m-%d %H:%M:%S")
            modified_time = datetime.fromtimestamp(file_stat.st_mtime).strftime("%Y-%m-%d %H:%M:%S")

            size_bytes = file_stat.st_size
            if size_bytes < 1024:
                size_str = f"{size_bytes} B"
            elif size_bytes < 1024 * 1024:
                size_str = f"{size_bytes/1024:.1f} KB"
            else:
                size_str = f"{size_bytes/(1024*1024):.1f} MB"

            return {"filename": filename, "created": created_time, "modified": modified_time, "size": size_str}

    def _build(self):
        # 戻るボタン
        back_button = ft.IconButton(icon=ft.icons.ARROW_BACK, on_click=self._go_back)

        # ヘッダー部分
        header = ft.Row(
            controls=[back_button, ft.Text("画像詳細", size=20, weight=ft.FontWeight.BOLD)],
            alignment=ft.MainAxisAlignment.START,
        )

        try:
            # ファイル情報を取得
            file_info = self._get_file_info()

            # 詳細情報を表示するカード
            info_card = ft.Card(
                content=ft.Container(
                    content=ft.Column(
                        controls=[
                            ft.Text("ファイル情報", size=16, weight=ft.FontWeight.BOLD),
                            ft.Divider(),
                            ft.Text(f"ファイル名: {file_info['filename']}", size=14),
                            ft.Text(f"作成日時: {file_info['created']}", size=14),
                            ft.Text(f"更新日時: {file_info['modified']}", size=14),
                            ft.Text(f"ファイルサイズ: {file_info['size']}", size=14),
                        ],
                        spacing=10,
                    ),
                    padding=20,
                )
            )

            # メインコンテンツ部分（画像と詳細情報を横に並べる）
            main_content = ft.Row(
                controls=[
                    # 左側：画像表示部分
                    ft.Container(
                        content=ft.Image(
                            src=self.image_path,
                            fit=ft.ImageFit.CONTAIN,
                        ),
                        expand=True,
                    ),
                    # 右側：詳細情報
                    ft.Container(
                        content=info_card,
                        width=450,
                        padding=10,
                    ),
                ],
                expand=True,
            )

            # レイアウトの構築
            self.controls = [
                ft.Container(
                    content=ft.Column(controls=[header, main_content], spacing=20, expand=True), padding=20, expand=True
                )
            ]
        except Exception as e:
            # エラーが発生した場合のフォールバック表示
            self.controls = [
                ft.Container(
                    content=ft.Column(
                        controls=[header, ft.Text(f"画像の読み込みに失敗しました: {str(e)}")], spacing=20
                    ),
                    padding=20,
                )
            ]

    def _go_back(self, _):
        self.page.go("/")  # トップページに戻る
        self.page.update()
