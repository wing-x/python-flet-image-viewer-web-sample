import flet as ft

from image_detail import ImageDetailView
from thumbnail import Thumbnail
import os
import glob

WEB_FLAG = True


class ImageViewer:
    def __init__(
        self,
        page: ft.Page,  # pageを追加
        images_dir: str = "images",
        images_per_row: int = 4,
        horizontal_spacing: int = 400,
        vertical_spacing: int = 600,
    ):
        self.page = page
        self.images_dir = images_dir
        self.images_per_row = images_per_row
        self.horizontal_spacing = horizontal_spacing
        self.vertical_spacing = vertical_spacing
        self.thumbnails = []
        self._create_thumbnails()

    def _get_image_files(self) -> list:
        if not WEB_FLAG:
            # 画像ファイルの一覧を取得
            glob_pattern = os.path.join(self.images_dir, "*.*")
            image_files = glob.glob(glob_pattern)
        else:
            image_files = [
                "images/sample_sdxl_001.png",
                "images/sample_sdxl_002.png",
                "images/sample_sdxl_003.png",
                "images/sample_sdxl_004.png",
                "images/sample_sdxl_005.png",
                "images/sample_sdxl_006.png",
                "images/sample_sdxl_007.png",
                "images/sample_sdxl_008.png",
                "images/sample_sdxl_009.png",
                "images/sample_sdxl_010.png",
            ]

        return image_files

    def _calculate_position(self, index: int) -> tuple:
        # サムネイルの位置を計算
        row = index // self.images_per_row
        col = index % self.images_per_row

        left = col * self.horizontal_spacing
        top = row * self.vertical_spacing

        return left, top

    def _navigate_to_detail(self, image_path: str):
        # 詳細ページへ遷移
        self.page.go(f"/detail?path={image_path}")
        self.page.update()

    def _create_thumbnails(self):
        # サムネイルを自動生成
        image_files = self._get_image_files()

        for index, image_path in enumerate(image_files):
            left, top = self._calculate_position(index)

            thumbnail = Thumbnail(
                image_path=image_path,
                left=left,
                top=top,
                on_click=self._navigate_to_detail,
            )
            self.thumbnails.append(thumbnail.gesture_detector)


def main(page: ft.Page):
    # Window configuration
    page.window_width = 800
    page.window_height = 600
    page.window_maximized = True
    page.window_center()

    def route_change(e: ft.RouteChangeEvent):
        # ルーティング処理
        page.views.clear()

        if page.route == "/":
            # トップページ（サムネイル一覧）
            image_viewer = ImageViewer(
                page=page,
                images_dir="assets/images",
                images_per_row=4,
                horizontal_spacing=400,
                vertical_spacing=600,
            )

            stack = [
                ft.Stack(
                    controls=image_viewer.thumbnails,
                    width=2000,
                    height=3000,
                ),
            ]

            column = ft.Column(
                controls=stack,
                spacing=10,
                scroll=ft.ScrollMode.ALWAYS,
                height=1000,
            )

            page.views.append(ft.View(route="/", controls=[ft.Text("画像一覧"), column]))
        else:
            # 詳細ページ
            image_path = page.route.split("?path=")[1]  # URLからパスを取得
            detail_view = ImageDetailView(page, image_path, WEB_FLAG)

            page.views.append(ft.View(route="/detail", controls=detail_view.controls))

        page.update()

    def view_pop(e: ft.ViewPopEvent):
        # 戻るボタン処理
        page.views.pop()
        top_view = page.views[-1]
        page.go(top_view.route)

    # ルーティングの設定
    page.on_route_change = route_change
    page.on_view_pop = view_pop

    # 初期ルートの設定
    page.go("/")


if WEB_FLAG:
    ft.app(main, view=ft.WEB_BROWSER)
else:
    ft.app(main)
